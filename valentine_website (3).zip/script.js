function yesClick() {
    window.location.href = "yes_page.html";
}

function moveNoButton() {
    let x = Math.random() * (window.innerWidth - 100);
    let y = Math.random() * (window.innerHeight - 50);
    document.getElementById("noBtn").style.left = x + "px";
    document.getElementById("noBtn").style.top = y + "px";
}